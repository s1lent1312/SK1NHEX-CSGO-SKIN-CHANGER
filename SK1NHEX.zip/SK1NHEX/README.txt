Requirements:

Operating System: Windows 10 / Windows 11 (64-bit)

Steam: Steam must be opened and running before launching the application

Internet connection recommended

Administrator privileges may be required for proper functionality

Make sure Steam is running in the background.

Extract all files to a folder of your choice.

Run the application as Administrator.

Close unnecessary background applications for best performance.
Do not move or delete files after installation.